# Hướng dẫn cài đặt
Đảm bảo đã cài đặt các mục sau đây:

- g++
- git

1. Git clone repo về
2. Browse đến folder `nachos`
3. Set quyền cho tất cả các file bên trong gnu-decstation-ultrix:
- Browse vào folder gnu-decstation-ultrix/decstation-ultrix/2.95.3
- `sudo chmod 0700 <tên file>` với từng file trong thư mục nầy.